// lib/models/meeting_room.dart

class MeetingRoom {
  final String? id; // 방 고유 ID (DB에서 생성)
  final String hostId; // 방장 UID (로그인한 유저)
  final String title; // 방 제목
  final String movieTitle; // 영화 제목

  // 선택 필드 (TMDB 연동용)
  final int? movieId; // TMDB movie id
  final String? moviePosterPath; // TMDB poster_path (예: "/abc123.jpg")

  final String theater; // 영화관
  final DateTime meetingTime; // 모임 날짜 및 시간
  final String password; // 입장 비밀번호 (4자리)
  final int maxMembers; // 최대 인원
  final List<String> participantIds; // 참여자 ID 목록
  final DateTime createdAt; // 방 생성 시간

  MeetingRoom({
    this.id,
    required this.hostId,
    required this.title,
    required this.movieTitle,
    this.movieId,
    this.moviePosterPath,
    required this.theater,
    required this.meetingTime,
    required this.password,
    this.maxMembers = 4,
    this.participantIds = const [],
    required this.createdAt,
  });

  // DB(JSON) 데이터를 앱에서 쓸 수 있게 변환
  factory MeetingRoom.fromJson(Map<String, dynamic> json, String id) {
    return MeetingRoom(
      id: id,
      hostId: (json['hostId'] ?? '').toString(),
      title: (json['title'] ?? '').toString(),
      movieTitle: (json['movieTitle'] ?? '').toString(),

      movieId: json['movieId'] is int
          ? json['movieId'] as int
          : int.tryParse((json['movieId'] ?? '').toString()),
      moviePosterPath: json['moviePosterPath'] == null
          ? null
          : json['moviePosterPath'].toString(),

      theater: (json['theater'] ?? '').toString(),
      meetingTime: DateTime.parse(json['meetingTime'].toString()),
      password: (json['password'] ?? '').toString(),
      maxMembers: (json['maxMembers'] ?? 4) is int
          ? (json['maxMembers'] ?? 4) as int
          : int.tryParse((json['maxMembers'] ?? '4').toString()) ?? 4,
      participantIds: List<String>.from(json['participantIds'] ?? const []),
      createdAt: DateTime.parse(json['createdAt'].toString()),
    );
  }

  // 앱 데이터를 DB(JSON)로 보낼 때 변환
  Map<String, dynamic> toJson() {
    return {
      'hostId': hostId,
      'title': title,
      'movieTitle': movieTitle,

      // 선택 필드
      'movieId': movieId,
      'moviePosterPath': moviePosterPath,

      'theater': theater,
      'meetingTime': meetingTime.toIso8601String(),
      'password': password,
      'maxMembers': maxMembers,
      'participantIds': participantIds,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  // 화면에서 바로 쓰기 편하게 URL 조립용 헬퍼 (선택)
  String? get moviePosterUrl {
    if (moviePosterPath == null || moviePosterPath!.isEmpty) return null;
    return 'https://image.tmdb.org/t/p/w780$moviePosterPath';
  }
}


extension MeetingRoomCopy on MeetingRoom {
  MeetingRoom copyWith({
    String? id,
    String? hostId,
    String? title,
    String? movieTitle,
    int? movieId,
    String? moviePosterPath,
    String? theater,
    DateTime? meetingTime,
    String? password,
    int? maxMembers,
    List<String>? participantIds,
    DateTime? createdAt,
  }) {
    return MeetingRoom(
      id: id ?? this.id,
      hostId: hostId ?? this.hostId,
      title: title ?? this.title,
      movieTitle: movieTitle ?? this.movieTitle,
      movieId: movieId ?? this.movieId,
      moviePosterPath: moviePosterPath ?? this.moviePosterPath,
      theater: theater ?? this.theater,
      meetingTime: meetingTime ?? this.meetingTime,
      password: password ?? this.password,
      maxMembers: maxMembers ?? this.maxMembers,
      participantIds: participantIds ?? this.participantIds,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}
