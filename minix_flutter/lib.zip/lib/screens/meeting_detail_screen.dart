// lib/screens/meeting_detail_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import '../controllers/auth_controller.dart';
import '../controllers/meeting_controller.dart';
import '../models/meeting_room.dart';

class MeetingDetailScreen extends StatelessWidget {
  const MeetingDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final MeetingRoom room = Get.arguments as MeetingRoom;

    final authController = Get.find<AuthController>();
    final meetingController = Get.find<MeetingController>();

    final myInfo = authController.user.value;
    final myUsername = (myInfo?.username ?? '').trim();
    final isMeHost = room.hostId == myUsername;

    final dateStr = DateFormat('M월 d일 (E) HH:mm', 'ko_KR').format(room.meetingTime);

    // ✅ 모델의 헬퍼 사용
    final posterUrl = room.moviePosterUrl;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
        title: Text(
          "모임 상세",
          style: GoogleFonts.notoSansKr(
            color: Colors.black,
            fontWeight: FontWeight.w800,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.share_outlined),
            onPressed: () {},
          ),
          if (isMeHost)
            IconButton(
              icon: const Icon(Icons.delete_outline, color: Colors.red),
              onPressed: () {
                Get.defaultDialog(
                  title: "모임 삭제",
                  middleText: "정말로 모임을 삭제하시겠습니까?\n삭제된 모임은 복구할 수 없습니다.",
                  textConfirm: "삭제",
                  confirmTextColor: Colors.white,
                  buttonColor: Colors.red,
                  textCancel: "취소",
                  onConfirm: () {
                    final id = room.id;
                    if (id == null || id.isEmpty) {
                      Get.back(); // dialog 닫기
                      Future.delayed(const Duration(milliseconds: 80), () {
                        if (Get.isSnackbarOpen == true) Get.closeAllSnackbars();
                        Get.snackbar(
                          "오류",
                          "방 ID가 없어 삭제할 수 없습니다.",
                          snackPosition: SnackPosition.BOTTOM,
                        );
                      });
                      return;
                    }

                    // ✅ 스낵바 큐 꼬임 방지
                    if (Get.isSnackbarOpen == true) {
                      Get.closeAllSnackbars();
                    }

                    // 1) 데이터 삭제
                    meetingController.deleteMeeting(id);

                    // 2) 다이얼로그 닫기
                    Get.back();

                    // 3) 상세 화면 닫기
                    Get.back();

                    // 4) pop 완료 후 스낵바
                    Future.delayed(const Duration(milliseconds: 120), () {
                      Get.snackbar(
                        "삭제 완료",
                        "모임이 삭제되었습니다.",
                        snackPosition: SnackPosition.BOTTOM,
                      );
                    });
                  },
                );
              },
            ),
          const SizedBox(width: 8),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 포스터 영역
            SizedBox(
              width: double.infinity,
              height: 260,
              child: posterUrl == null
                  ? Container(
                      color: Colors.grey[200],
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.movie_creation_outlined, size: 60, color: Colors.grey),
                          const SizedBox(height: 10),
                          Text(
                            room.movieTitle,
                            style: GoogleFonts.notoSansKr(
                              fontSize: 20,
                              fontWeight: FontWeight.w800,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    )
                  : Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.network(
                          posterUrl,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            color: Colors.grey[200],
                            child: const Center(
                              child: Icon(Icons.broken_image, size: 48, color: Colors.grey),
                            ),
                          ),
                        ),
                        Container(
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [Color(0x15000000), Color(0xB0000000)],
                            ),
                          ),
                        ),
                        Positioned(
                          left: 16,
                          right: 16,
                          bottom: 16,
                          child: Text(
                            room.movieTitle,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.notoSansKr(
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
            ),

            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    room.title,
                    style: GoogleFonts.notoSansKr(
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      height: 1.3,
                    ),
                  ),
                  const SizedBox(height: 20),

                  _infoRow(Icons.calendar_today, dateStr),
                  const SizedBox(height: 12),
                  _infoRow(Icons.location_on_outlined, room.theater),
                  const SizedBox(height: 12),
                  _infoRow(
                    Icons.person_outline,
                    isMeHost
                        ? "호스트: ${(myUsername.isEmpty ? room.hostId : myUsername)} (나)"
                        : "호스트: ${room.hostId}",
                  ),

                  const Divider(height: 40, thickness: 1),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "참여 멤버 (${room.participantIds.length}/${room.maxMembers})",
                        style: GoogleFonts.notoSansKr(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF5F7FA),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      children: room.participantIds.map((name) {
                        final n = name.trim();
                        final isMe = (myUsername.isNotEmpty && n == myUsername);
                        final isHost = (n == room.hostId);

                        final avatarText = (n.isNotEmpty ? n[0] : 'G').toUpperCase();

                        return Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: Row(
                            children: [
                              CircleAvatar(
                                backgroundColor: const Color(0XFF4E73DF),
                                child: Text(
                                  avatarText,
                                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  isMe ? "$n (나)" : n,
                                  style: GoogleFonts.notoSansKr(
                                    fontWeight: FontWeight.w700,
                                    color: Colors.black87,
                                  ),
                                ),
                              ),
                              if (isHost)
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(6),
                                    border: Border.all(color: Colors.grey.shade300),
                                  ),
                                  child: Text(
                                    "방장",
                                    style: GoogleFonts.notoSansKr(
                                      fontSize: 11,
                                      color: Colors.blueAccent,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: ElevatedButton(
            onPressed: () {
              if (Get.isSnackbarOpen == true) Get.closeAllSnackbars();
              Get.snackbar("알림", "곧 채팅 기능이 추가됩니다.", snackPosition: SnackPosition.BOTTOM);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0XFF4E73DF),
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: 0,
            ),
            child: Text(
              "채팅방 입장하기",
              style: GoogleFonts.notoSansKr(
                fontSize: 16,
                color: Colors.white,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _infoRow(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, size: 20, color: Colors.grey[600]),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            text,
            style: GoogleFonts.notoSansKr(
              fontSize: 15,
              color: Colors.black87,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }
}
