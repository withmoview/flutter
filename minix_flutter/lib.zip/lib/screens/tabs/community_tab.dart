import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:minix_flutter/controllers/TweetController.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../widgets/review_card_from_tweet.dart';

/// KakaoBank-ish flat style tokens (Home/Meeting과 통일)
const _kBg = Color(0xFFF4F6F8);
const _kCard = Colors.white;
const _kBorder = Color(0xFFE6E8EE);
const _kText = Color(0xFF141A2A);
const _kSub = Color(0xFF6B7280);
const _kPrimary = Color(0xFF4E73DF);

final _kCardDecoration = BoxDecoration(
  color: _kCard,
  borderRadius: BorderRadius.circular(16),
  border: Border.all(color: _kBorder, width: 1),
);

class CommunityTab extends StatelessWidget {
  const CommunityTab({super.key});

  @override
  Widget build(BuildContext context) {
    final tweetcontroller = Get.find<TweetController>();

    return Scaffold(
      backgroundColor: _kBg,

      // ✅ 홈/미팅과 같은 "떠있는 헤더" 느낌 (AppBar 대신)
      appBar: AppBar(
        backgroundColor: _kBg,
        elevation: 0,
        scrolledUnderElevation: 0,
        automaticallyImplyLeading: false,
        toolbarHeight: 70,
        titleSpacing: 16,
        title: Row(
          children: [
            // withmovie pill
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _kBorder),
              ),
              child: Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    margin: const EdgeInsets.only(right: 8),
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: _kPrimary,
                    ),
                  ),
                  Text(
                    'withmovie',
                    style: GoogleFonts.poppins(
                      color: _kText,
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
            const Spacer(),
            _CircleIconButton(
              icon: Icons.person_outline,
              onTap: () => Get.toNamed('/profile'),
            ),
            const SizedBox(width: 10),
            _CircleIconButton(
              icon: Icons.logout,
              iconColor: Colors.redAccent,
              onTap: () => Get.offAllNamed('/'),
            ),
          ],
        ),
      ),

      floatingActionButton: FloatingActionButton(
        onPressed: () => Get.toNamed('/compose'),
        backgroundColor: _kPrimary,
        elevation: 0,
        child: const Icon(Icons.edit, color: Colors.white),
      ),

      body: Obx(() {
        if (tweetcontroller.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        }

        return RefreshIndicator(
          onRefresh: () => tweetcontroller.loadTimeline(),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 120), // 바텀바/플로팅 여백
            children: [
              // ✅ 섹션 타이틀(모임탭처럼)
              Text(
                '커뮤니티',
                style: GoogleFonts.notoSansKr(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: _kText,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                '리뷰를 공유하고 서로의 취향을 알아보세요.',
                style: GoogleFonts.notoSansKr(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w600,
                  color: _kSub,
                ),
              ),

              const SizedBox(height: 14),

              // ✅ 상단 안내 카드 (플랫 + 보더)
              Container(
                padding: const EdgeInsets.all(14),
                decoration: _kCardDecoration,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: _kBg,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: _kBorder),
                      ),
                      child: const Center(
                        child: Text('🧾', style: TextStyle(fontSize: 18)),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '리뷰',
                            style: GoogleFonts.notoSansKr(
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              color: _kText,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '영화 평점/한줄평을 기록하고 공유해보세요.',
                            style: GoogleFonts.notoSansKr(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: _kSub,
                              height: 1.35,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 12),

              // ✅ 필터 + 작성 버튼 (플랫)
              Row(
                children: [
                  _FilterChip(label: '내 리뷰', onTap: () {}),
                  const SizedBox(width: 8),
                  _FilterChip(label: '모임 리뷰', onTap: () {}),
                  const SizedBox(width: 8),
                  _FilterChip(label: '최신순', onTap: () {}),
                  const Spacer(),
                  _PrimaryButton(
                    text: '작성',
                    onTap: () => Get.toNamed('/compose'),
                  ),
                ],
              ),

              const SizedBox(height: 12),

              // ✅ 리스트 컨테이너 (플랫 + 보더)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: _kCardDecoration,
                child: tweetcontroller.tweets.isEmpty
                    ? Padding(
                        padding: const EdgeInsets.all(24),
                        child: Center(
                          child: Text(
                            '아직 리뷰가 없습니다',
                            style: GoogleFonts.notoSansKr(
                              color: _kSub,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      )
                    : Column(
                        children: List.generate(tweetcontroller.tweets.length, (i) {
                          final tweet = tweetcontroller.tweets[i];
                          return Padding(
                            padding: EdgeInsets.only(
                              bottom: i == tweetcontroller.tweets.length - 1 ? 0 : 12,
                            ),
                            child: ReviewCardFromTweet(
                              tweet: tweet,
                              onLike: () => tweetcontroller.toggleLike(tweet.id),
                              onDelete: () => tweetcontroller.deleteTweet(tweet.id),
                            ),
                          );
                        }),
                      ),
              ),
            ],
          ),
        );
      }),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _FilterChip({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(999),
        child: Ink(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(999),
            border: Border.all(color: _kBorder),
          ),
          child: Text(
            label,
            style: GoogleFonts.notoSansKr(
              fontSize: 12.5,
              fontWeight: FontWeight.w800,
              color: _kText,
            ),
          ),
        ),
      ),
    );
  }
}

class _PrimaryButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const _PrimaryButton({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: _kPrimary,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Text(
            text,
            style: GoogleFonts.notoSansKr(
              color: Colors.white,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
      ),
    );
  }
}

class _CircleIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final Color? iconColor;

  const _CircleIconButton({
    required this.icon,
    required this.onTap,
    this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: _kBorder),
          ),
          child: Icon(icon, color: iconColor ?? _kText),
        ),
      ),
    );
  }
}
