// lib/screens/create_meeting_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:minix_flutter/controllers/meeting_controller.dart';
import 'movie_search_screen.dart';

class CreateMeetingScreen extends StatelessWidget {
  const CreateMeetingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // ✅ build마다 새로 생성 방지 (이미 등록돼 있으면 find)
    final controller = Get.isRegistered<MeetingController>()
        ? Get.find<MeetingController>()
        : Get.put(MeetingController());

    const primaryColor = Color(0XFF4E73DF);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          '모임 만들기',
          style: GoogleFonts.notoSansKr(
            fontWeight: FontWeight.w700,
            color: Colors.black87,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.black87),
          onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildLabel('모임 제목'),
            _buildTextField(
              controller: controller.titleController,
              hint: '예: 이번 주말 듄2 보러 가실 분',
              icon: Icons.campaign_outlined,
            ),
            const SizedBox(height: 24),

            // ----------------------------
            // ✅ 영화 선택(검색)
            // ----------------------------
            _buildLabel('영화 선택'),
            Obx(() {
              // ✅ 영화 제목은 movieController.text 로 관리
              final title = controller.movieController.text.trim();
              final posterPath = controller.selectedMoviePosterPath.value.trim();

              final posterUrl = posterPath.isEmpty
                  ? null
                  : 'https://image.tmdb.org/t/p/w500$posterPath';

              return InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () async {
                  final result = await Get.to(() => const MovieSearchScreen());
                  if (result == null) return;

                  int? id;
                  String? pickedTitle;
                  String? pickedPosterPath;

                  // MoviePickResult / Map 둘 다 대응
                  if (result is MoviePickResult) {
                    id = result.id;
                    pickedTitle = result.title;
                    pickedPosterPath = result.posterPath;
                  } else if (result is Map) {
                    final rawId = result['id'];
                    id = rawId is int ? rawId : int.tryParse(rawId?.toString() ?? '');
                    pickedTitle = result['title']?.toString();
                    pickedPosterPath =
                        result['posterPath']?.toString() ?? result['poster_path']?.toString();
                  }

                  if (id == null || (pickedTitle ?? '').trim().isEmpty) {
                    _safeSnack('오류', '영화 선택 데이터를 읽지 못했습니다.');
                    return;
                  }

                  // ✅ 컨트롤러 시그니처 맞춤
                  controller.setSelectedMovie(
                    movieId: id,
                    title: pickedTitle!.trim(),
                    posterPath: pickedPosterPath,
                  );
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF5F7FA),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: SizedBox(
                          width: 46,
                          height: 64,
                          child: posterUrl == null
                              ? Container(
                                  color: Colors.grey.shade300,
                                  child: const Icon(Icons.search, color: Colors.black45),
                                )
                              : Image.network(
                                  posterUrl,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Container(
                                    color: Colors.grey.shade300,
                                    child: const Icon(Icons.broken_image, color: Colors.black45),
                                  ),
                                ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          title.isEmpty ? '영화를 검색해서 선택하세요' : title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: GoogleFonts.notoSansKr(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: title.isEmpty ? Colors.grey[500] : Colors.black87,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Icon(Icons.chevron_right, color: Colors.grey[500]),
                    ],
                  ),
                ),
              );
            }),
            const SizedBox(height: 24),

            _buildLabel('상영관 / 장소'),
            _buildTextField(
              controller: controller.theaterController,
              hint: '예: CGV 용산아이파크몰',
              icon: Icons.location_on_outlined,
            ),
            const SizedBox(height: 24),

            // 날짜 및 시간
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildLabel('날짜'),
                      Obx(() => _buildPickerButton(
                            text: controller.selectedDate.value == null
                                ? '날짜 선택'
                                : '${controller.selectedDate.value!.year}-${controller.selectedDate.value!.month}-${controller.selectedDate.value!.day}',
                            icon: Icons.calendar_today,
                            onTap: () async {
                              final date = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime.now(),
                                lastDate: DateTime(2030),
                              );
                              if (date != null) controller.selectedDate.value = date;
                            },
                          )),
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildLabel('시간'),
                      Obx(() => _buildPickerButton(
                            text: controller.selectedTime.value == null
                                ? '시간 선택'
                                : '${controller.selectedTime.value!.hour}:${controller.selectedTime.value!.minute.toString().padLeft(2, '0')}',
                            icon: Icons.access_time,
                            onTap: () async {
                              final time = await showTimePicker(
                                context: context,
                                initialTime: TimeOfDay.now(),
                              );
                              if (time != null) controller.selectedTime.value = time;
                            },
                          )),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),

            _buildLabel('비밀번호 (4자리)'),
            _buildPasswordField(
              controller: controller.passwordController,
              hint: '숫자 4자리 입력',
              icon: Icons.lock_outline,
            ),

            const SizedBox(height: 40),

            SizedBox(
              width: double.infinity,
              height: 56,
              child: Obx(() => ElevatedButton(
                    onPressed: controller.isLoading.value
                        ? null
                        : () async {
                            // ✅ 여기서 성공하면 pop
                            try {
                              await controller.createMeetingRoom();
                              // createMeetingRoom 내부에서 검증 실패하면 snackbar 띄우고 return 하니까
                              // 여기선 "정상 생성 후"에만 실행되도록 설계되어 있어야 합니다.
                              // (컨트롤러에서 rethrow 하는 에러만 catch)
                              Get.back();
                              Future.delayed(const Duration(milliseconds: 120), () {
                                if (Get.isSnackbarOpen == true) Get.closeAllSnackbars();
                                Get.snackbar(
                                  '완료',
                                  '모임이 생성되었습니다.',
                                  snackPosition: SnackPosition.BOTTOM,
                                );
                              });
                            } catch (e) {
                              _safeSnack('오류', '모임 생성 중 문제가 발생했습니다.');
                            }
                          },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: primaryColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      elevation: 0,
                    ),
                    child: controller.isLoading.value
                        ? const CircularProgressIndicator(color: Colors.white)
                        : Text(
                            '모임 개설하기',
                            style: GoogleFonts.notoSansKr(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                  )),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  // ---------- UI Helpers ----------

  Widget _buildLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        text,
        style: GoogleFonts.notoSansKr(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: Colors.grey[700],
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFF5F7FA),
        borderRadius: BorderRadius.circular(12),
      ),
      child: TextField(
        controller: controller,
        keyboardType: TextInputType.text,
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: Colors.grey[500], size: 20),
          hintText: hint,
          hintStyle: TextStyle(color: Colors.grey[400], fontSize: 14),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      ),
    );
  }

  Widget _buildPasswordField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFF5F7FA),
        borderRadius: BorderRadius.circular(12),
      ),
      child: TextField(
        controller: controller,
        keyboardType: TextInputType.number,
        obscureText: true,
        inputFormatters: [
          FilteringTextInputFormatter.digitsOnly,
          LengthLimitingTextInputFormatter(4),
        ],
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: Colors.grey[500], size: 20),
          hintText: hint,
          hintStyle: TextStyle(color: Colors.grey[400], fontSize: 14),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      ),
    );
  }

  Widget _buildPickerButton({
    required String text,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
        decoration: BoxDecoration(
          color: const Color(0xFFF5F7FA),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.grey[500], size: 20),
            const SizedBox(width: 8),
            Text(
              text,
              style: TextStyle(
                color: text.contains('선택') ? Colors.grey[400] : Colors.black87,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _safeSnack(String title, String msg) {
    if (Get.isSnackbarOpen == true) Get.closeAllSnackbars();
    Get.snackbar(title, msg, snackPosition: SnackPosition.BOTTOM);
  }
}
