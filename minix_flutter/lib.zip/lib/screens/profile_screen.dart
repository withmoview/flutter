import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import '../controllers/auth_controller.dart';
import '../controllers/meeting_controller.dart';
import '../models/meeting_room.dart';
import '../screens/webview_screen.dart';
import '../services/api_service.dart';
import '../screens/meeting_detail_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _authController = Get.find<AuthController>();
  final _api = Get.find<ApiService>();

  // ✅ MeetingController는 전역에 등록돼 있어야 Get.find가 됩니다.
  // 혹시 아직 등록 안 된 상태면 안전하게 put 합니다.
  late final MeetingController _meetingController;

  final Color _primaryColor = const Color(0xFF4E73DF);
  final Color _backgroundColor = const Color(0xFFF5F7FA);

  @override
  void initState() {
    super.initState();
    _meetingController = Get.isRegistered<MeetingController>()
        ? Get.find<MeetingController>()
        : Get.put(MeetingController(), permanent: true);
  }

  // 프로필 이미지 변경 로직
  Future<void> _changeProfileImage() async {
    final image = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      maxWidth: 800,
    );
    if (image == null) return;

    try {
      // 1) 파일 업로드
      final fileId = await _api.uploadImage(image);
      if (fileId == null) {
        Get.snackbar('오류', '이미지 업로드에 실패했습니다');
        return;
      }

      // 2) 프로필 정보 업데이트
      final success = await _api.updateProfile(profileImageId: fileId);
      if (success != null) {
        Get.snackbar('완료', '프로필 이미지가 변경되었습니다');
        await _authController.loadProfile();
      }
    } catch (e) {
      Get.snackbar('오류', '프로필 수정에 실패했습니다');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _backgroundColor,
      appBar: AppBar(
        title: Text(
          'Profile',
          style: GoogleFonts.poppins(
            color: Colors.black,
            fontWeight: FontWeight.w700,
            fontSize: 28,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.redAccent),
            onPressed: () => _authController.logout(),
          ),
        ],
      ),
      body: _buildContent(),
    );
  }

  Widget _buildContent() {
    return Obx(() {
      final user = _authController.user.value;
      if (user == null) return const SizedBox();

      final myUsername = user.username;

      // ✅ 내가 참가한 모임만 필터링
      final joinedRooms = _meetingController.meetings
          .where((r) => r.participantIds.contains(myUsername))
          .toList();

      // 보기 편하게 시간순 정렬(가까운 일정 먼저)
      joinedRooms.sort((a, b) => a.meetingTime.compareTo(b.meetingTime));

      return SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 20),

            // 1) 프로필 카드
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 15,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Stack(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: _primaryColor.withOpacity(0.3),
                              blurRadius: 15,
                              offset: const Offset(0, 5),
                            ),
                          ],
                        ),
                        child: CircleAvatar(
                          radius: 45,
                          backgroundImage: user.profile_image_id != null
                              ? NetworkImage(_api.getImageUrl(user.profile_image_id!))
                              : null,
                          backgroundColor: _primaryColor,
                          child: user.profile_image_id == null
                              ? Text(
                                  user.name.isNotEmpty
                                      ? user.name[0].toUpperCase()
                                      : '?',
                                  style: const TextStyle(
                                    fontSize: 36,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                )
                              : null,
                        ),
                      ),
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: InkWell(
                          onTap: _changeProfileImage,
                          child: Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.grey[200]!),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.1),
                                  blurRadius: 5,
                                ),
                              ],
                            ),
                            child: Icon(
                              Icons.camera_alt,
                              size: 18,
                              color: Colors.grey[700],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  Text(
                    user.name,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.5,
                    ),
                  ),
                  const SizedBox(height: 4),

                  Text(
                    '@${user.username}',
                    style: TextStyle(
                      fontSize: 15,
                      color: Colors.grey[600],
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 24),

                  // 통계 & 약관
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildInfoItem(
                        count: joinedRooms.length.toString(),
                        label: "참가 모임",
                      ),
                      Container(height: 30, width: 1, color: Colors.grey[300]),
                      TextButton(
                        onPressed: () {
                          Get.to(() => const WebViewScreen(
                                title: '이용약관',
                                url: 'https://banawy.store',
                              ));
                        },
                        style: TextButton.styleFrom(
                          foregroundColor: Colors.grey[700],
                        ),
                        child: const Column(
                          children: [
                            Icon(Icons.description_outlined, size: 22),
                            SizedBox(height: 4),
                            Text("이용약관", style: TextStyle(fontSize: 12)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // 2) 리스트 헤더
            Padding(
              padding: const EdgeInsets.only(left: 24, bottom: 10),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "참가한 모임",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
              ),
            ),

            // 3) 참가 모임 목록
            if (joinedRooms.isEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 40),
                child: Center(
                  child: Column(
                    children: [
                      Icon(Icons.event_busy_outlined, size: 48, color: Colors.grey[300]),
                      const SizedBox(height: 10),
                      Text(
                        '참가한 모임이 없습니다',
                        style: TextStyle(color: Colors.grey[500]),
                      ),
                    ],
                  ),
                ),
              )
            else
              ListView.separated(
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 0),
                itemCount: joinedRooms.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, index) {
                  final room = joinedRooms[index];
                  return _JoinedMeetingCard(
                    room: room,
                    primaryColor: _primaryColor,
                    onTap: () {
                      // ✅ 참가한 모임이니 비번 없이 상세로 바로 이동
                      Get.to(() => const MeetingDetailScreen(), arguments: room);
                    },
                  );
                },
              ),

            const SizedBox(height: 40),
          ],
        ),
      );
    });
  }

  Widget _buildInfoItem({required String count, required String label}) {
    return Column(
      children: [
        Text(
          count,
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: _primaryColor,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(fontSize: 12, color: Colors.grey),
        ),
      ],
    );
  }
}

class _JoinedMeetingCard extends StatelessWidget {
  final MeetingRoom room;
  final Color primaryColor;
  final VoidCallback onTap;

  const _JoinedMeetingCard({
    required this.room,
    required this.primaryColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final dateStr = DateFormat('M월 d일 (E) HH:mm', 'ko_KR').format(room.meetingTime);
    final isUpcoming = room.meetingTime.isAfter(DateTime.now());

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 상태 + 날짜
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: (isUpcoming ? primaryColor : Colors.grey).withOpacity(0.12),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    isUpcoming ? "예정" : "지난 모임",
                    style: TextStyle(
                      color: isUpcoming ? primaryColor : Colors.grey[700],
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Text(dateStr, style: const TextStyle(color: Colors.black54, fontSize: 13)),
              ],
            ),
            const SizedBox(height: 12),

            // 제목
            Text(
              room.title,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 8),

            // 영화/장소
            Row(
              children: [
                const Icon(Icons.movie_outlined, size: 16, color: Colors.grey),
                const SizedBox(width: 4),
                Flexible(
                  child: Text(
                    room.movieTitle,
                    style: const TextStyle(fontSize: 14, color: Colors.black87),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                const Icon(Icons.location_on_outlined, size: 16, color: Colors.grey),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    room.theater,
                    style: const TextStyle(fontSize: 14, color: Colors.black87),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // 참여 인원
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                const Icon(Icons.people_outline, size: 16, color: Colors.grey),
                const SizedBox(width: 4),
                Text(
                  "${room.participantIds.length}/${room.maxMembers}명",
                  style: const TextStyle(color: Colors.grey, fontSize: 13),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
