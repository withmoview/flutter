// lib/controllers/meeting_controller.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../models/meeting_room.dart';
import 'auth_controller.dart';

class MeetingController extends GetxController {
  // 입력 컨트롤러
  final titleController = TextEditingController();
  final movieController = TextEditingController();
  final theaterController = TextEditingController();
  final passwordController = TextEditingController();

  // 선택 값
  final Rx<DateTime?> selectedDate = Rx<DateTime?>(null);
  final Rx<TimeOfDay?> selectedTime = Rx<TimeOfDay?>(null);

  // ✅ TMDB 선택값 (선택)
  // MovieSearchScreen에서 선택한 영화 정보를 넣어주세요.
  final RxInt selectedMovieId = RxInt(-1); // -1 = 미선택
  final RxString selectedMoviePosterPath = ''.obs; // '' = 미선택

  // 상태
  final isLoading = false.obs;

  // 메모리 저장소
  final RxList<MeetingRoom> meetings = <MeetingRoom>[].obs;

  @override
  void onClose() {
    titleController.dispose();
    movieController.dispose();
    theaterController.dispose();
    passwordController.dispose();
    super.onClose();
  }

  /// ✅ 영화 선택값 세팅용 (MovieSearchScreen에서 호출)
  void setSelectedMovie({
    required int movieId,
    required String title,
    String? posterPath,
  }) {
    selectedMovieId.value = movieId;
    selectedMoviePosterPath.value = posterPath ?? '';
    movieController.text = title;
  }

  void clearSelectedMovie() {
    selectedMovieId.value = -1;
    selectedMoviePosterPath.value = '';
  }

  Future<void> createMeetingRoom() async {
    final title = titleController.text.trim();
    final movieTitle = movieController.text.trim();
    final theater = theaterController.text.trim();
    final pw = passwordController.text.trim();

    if (title.isEmpty ||
        movieTitle.isEmpty ||
        theater.isEmpty ||
        pw.isEmpty ||
        selectedDate.value == null ||
        selectedTime.value == null) {
      Get.snackbar(
        "알림",
        "모든 정보를 입력해주세요.",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.orange,
        colorText: Colors.white,
      );
      return;
    }

    // 비밀번호 4자리 체크
    if (!RegExp(r'^\d{4}$').hasMatch(pw)) {
      Get.snackbar(
        "알림",
        "비밀번호는 숫자 4자리여야 합니다.",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.orange,
        colorText: Colors.white,
      );
      return;
    }

    isLoading.value = true;

    try {
      final date = selectedDate.value!;
      final time = selectedTime.value!;
      final meetingTime = DateTime(date.year, date.month, date.day, time.hour, time.minute);

      final auth = Get.find<AuthController>();
      final myInfo = auth.user.value;
      final myName = (myInfo?.username ?? '').trim().isEmpty ? '익명' : myInfo!.username.trim();

      // ✅ 선택된 영화 정보 (없으면 null)
      final int? movieId = (selectedMovieId.value >= 0) ? selectedMovieId.value : null;
      final String? posterPath = selectedMoviePosterPath.value.trim().isEmpty
          ? null
          : selectedMoviePosterPath.value.trim();

      final newRoom = MeetingRoom(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        hostId: myName,
        title: title,
        movieTitle: movieTitle,
        movieId: movieId,
        moviePosterPath: posterPath,
        theater: theater,
        meetingTime: meetingTime,
        password: pw,
        maxMembers: 4,
        participantIds: [myName],
        createdAt: DateTime.now(),
      );

      meetings.insert(0, newRoom);

      // 입력 초기화
      _clearFields();
      clearSelectedMovie();

      // ⚠️ 여기서 Get.back() / Get.snackbar() 하지 않는 걸 추천합니다.
      // (UI에서 화면 pop 이후 snackbar 띄우면 안정적)
    } catch (e) {
      debugPrint("createMeetingRoom error: $e");
      rethrow;
    } finally {
      isLoading.value = false;
    }
  }

  void _clearFields() {
    titleController.clear();
    movieController.clear();
    theaterController.clear();
    passwordController.clear();
    selectedDate.value = null;
    selectedTime.value = null;
  }

  bool checkPassword(MeetingRoom room, String inputPassword) {
    return room.password == inputPassword.trim();
  }

  /// ✅ 데이터만 삭제 (UI에서 화면 pop & snackbar 처리)
  void deleteMeeting(String roomId) {
    meetings.removeWhere((room) => room.id == roomId);
  }

  /// (옵션) 참가 기능
  bool joinMeeting(String roomId, String username) {
    final idx = meetings.indexWhere((r) => r.id == roomId);
    if (idx < 0) return false;

    final room = meetings[idx];
    if (room.participantIds.contains(username)) return true;
    if (room.participantIds.length >= room.maxMembers) return false;

    meetings[idx] = room.copyWith(participantIds: [...room.participantIds, username]);
    return true;
  }
}
